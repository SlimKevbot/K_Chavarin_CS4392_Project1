Kevin Chavarin CS 4392 Project 1
Programmed using PyCharm
This projected was created to get a better understanding of sockets

Required Environment: Python 3.9

Libraries: argparse, socket, logging

Flow of execution:
Script imports libraries
Arguments taken from command line upon running the script
Arguments are checked and errors are given when necessary
Socket object and logging object are created
Arguments are used in connecting to Server 
User is asked to send a message to Server
Wait for reply
Display Reply
Exit